/*
 * Copyright (c) "Neo4j"
 * Neo4j Sweden AB [https://neo4j.com]
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package config

import (
	"crypto/tls"
	"net/url"
	"time"

	"github.com/neo4j/neo4j-go-driver/v6/neo4j/auth"
	"github.com/neo4j/neo4j-go-driver/v6/neo4j/log"
	"github.com/neo4j/neo4j-go-driver/v6/neo4j/notifications"
)

// A Config contains options that can be used to customize certain
// aspects of the driver
type Config struct {
	// TlsConfig defines the TLS configuration of the driver.
	//
	// The configuration is only used for URI schemes 'bolt+s', 'bolt+ssc',
	// 'neo4j+s' and 'neo4j+ssc'.
	//
	// The default MinVersion attribute is tls.VersionTLS12. This is overridable.
	// The InsecureSkipVerify attribute of TlsConfig is always derived from the initial URI scheme.
	// The ServerName attribute of TlsConfig is always derived from the initial URI host.
	//
	// ExampleConfig_tlsSelfSignedCertificates shows how to configure TLS for self-signed certificates.
	//
	// This is considered an advanced setting, use it at your own risk.
	// Introduced in 5.0.
	TlsConfig *tls.Config
	// ClientCertificateProvider specifies a provider for the client TLS certificate for mutual TLS authentication.
	// Use auth.NewStaticClientCertificateProvider for static certificates, or auth.NewRotatingClientCertificateProvider
	// for certificates that require runtime updates without application restart.
	//
	// Static certificate example:
	//   config.ClientCertificateProvider = auth.NewStaticClientCertificateProvider(auth.ClientCertificateProvider{
	//       CertFile: "path/to/client.crt",
	//       KeyFile:  "path/to/client.key",
	//   })
	//
	// Rotatable certificate example:
	//   provider, _ := auth.NewRotatingClientCertificateProvider(auth.ClientCertificateProvider{
	//       CertFile: "path/to/initial_client.crt",
	//       KeyFile:  "path/to/initial_client.key",
	//   })
	//   config.ClientCertificateProvider = provider
	//   // Dynamically update the certificate later without restarting the application.
	//   _ = provider.UpdateCertificate(auth.ClientCertificateProvider{
	//       CertFile: "path/to/new_client.crt",
	//       KeyFile:  "path/to/new_client.key",
	//   })
	//
	// Note: This option is not applicable for 'bolt://' or 'neo4j://' schemes where encryption isn't used.
	ClientCertificateProvider auth.ClientCertificateProvider
	// Logging target the driver will send its log outputs
	//
	// Possible to use custom logger (implement log.Logger interface) or
	// use log.ToConsole.
	//
	// default: No Op Logger (log.ToVoid)
	Log log.Logger
	// Resolver that would be used to resolve initial router address. This may
	// be useful if you want to provide more than one URL for initial router.
	// If not specified, the URL provided to NewDriver
	// is used as the initial router.
	//
	// default: nil
	AddressResolver ServerAddressResolver
	// Maximum amount of time a retryable operation would continue retrying. It
	// cannot be specified as a negative value.
	//
	// default: 30 * time.Second
	MaxTransactionRetryTime time.Duration
	// Maximum number of connections per URL to allow on this driver. It
	// cannot be specified as 0 and negative values are interpreted as
	// math.MaxInt32.
	//
	// default: 100
	MaxConnectionPoolSize int
	// Maximum connection lifetime on pooled connections. Values less than
	// or equal to 0 disables the lifetime check.
	//
	// default: 1 * time.Hour
	MaxConnectionLifetime time.Duration
	// Maximum amount of time to either acquire an idle connection from the pool
	// or create a new connection (when the pool is not full). Negative values
	// result in an infinite wait time, whereas a 0 value results in no timeout.
	// If no timeout is set, an immediate failure follows when there are no
	// available connections.
	//
	// Since 4.3, this setting competes with connection read timeout hints, if
	// the server-side option called
	// "dbms.connector.bolt.connection_keep_alive_for_requests" is enabled.
	// The read timeout is automatically applied and may result in connections
	// being dropped if they are idle beyond the corresponding period.
	//
	// Since 5.0, this setting competes with the context-aware APIs. In v5, these APIs
	// were discoverable through NewDriverWithContext; in v6, all APIs are context-aware by default.
	// When a connection needs to be acquired from the internal driver
	// connection pool and the user-provided context.Context carries a deadline
	// (through context.WithTimeout or context.WithDeadline), the earliest
	// deadline wins. Connections are still subject to early terminations if a read timeout
	// hint is received.
	//
	// default: 1 * time.Minute
	ConnectionAcquisitionTimeout time.Duration
	// ConnectionLivenessCheckTimeout sets the timeout duration for idle connections in the pool.
	// Connections idle longer than this timeout will be tested for liveliness before reuse. A low timeout value
	// can increase network requests when acquiring a connection, impacting performance. Conversely, a high
	// timeout may result in using connections that are no longer active, causing exceptions in your application.
	// These exceptions typically resolve with a retry or using a driver API with automatic
	// retries, assuming the database is operational.
	//
	// The parameter balances the likelihood of encountering connection issues against performance.
	// Typically, adjustment of this parameter is not necessary.
	//
	// By default, no liveliness check is performed. A value of 0 ensures connections are always tested for
	// validity, and negative values are not permitted.
	//
	// default: pool.DefaultConnectionLivenessCheckTimeout
	ConnectionLivenessCheckTimeout time.Duration
	// Connect timeout that will be set on underlying sockets. Values less than
	// or equal to 0 results in no timeout being applied.
	//
	// Since 5.0, this setting competes with the context-aware APIs. In v5, these APIs
	// were discoverable through NewDriverWithContext; in v6, all APIs are context-aware by default.
	// If a connection needs to be created when one of these APIs is called
	// and the user-provided context.Context carries a deadline (through
	// context.WithTimeout or context.WithDeadline), the TCP dialer will pick
	// the earliest between this setting and the context deadline.
	//
	// default: 5 * time.Second
	SocketConnectTimeout time.Duration
	// Whether to enable TCP keep alive on underlying sockets.
	//
	// default: true
	SocketKeepalive bool
	// Optionally override the user agent string sent to Neo4j server.
	//
	// default: neo4j.UserAgent
	UserAgent string
	// FetchSize defines how many records to pull from server in each batch.
	// From Bolt protocol v4 (Neo4j 4+) records can be fetched in batches as
	// compared to fetching all in previous versions.
	// If the underlying protocol does not support FetchSize, it is ignored.
	//
	// If FetchSize is set to `FetchDefault`, the driver decides the appropriate size.
	// If set to a positive value that size is used; negative values behaves as `FetchAll` (see below).
	//
	// To turn off fetching in batches and always fetch everything, set FetchSize to `FetchAll`.
	// A limited FetchSize ensures the client is not overflown with records,
	// and allows to bound memory usage.
	FetchSize int
	// NotificationsMinSeverity defines the minimum severity level of notifications the server should send.
	// By default, the server's settings are used.
	// Disabling severities allows the server to skip analysis for those, which can speed up query execution.
	NotificationsMinSeverity notifications.NotificationMinimumSeverityLevel
	// NotificationsDisabledCategories defines the categories of notifications the server should not send.
	// By default, the server's settings are used.
	// Disabling categories allows the server to skip analysis for those, which can speed up query execution.
	//
	// Deprecated: Use NotificationsDisabledClassifications instead. This will be removed in a future release.
	//lint:ignore SA1019 NotificationDisabledCategories is supported for backward compatibility
	NotificationsDisabledCategories notifications.NotificationDisabledCategories
	// NotificationsDisabledClassifications defines the classifications of notifications the server should not send.
	// By default, the server's settings are used.
	// Disabling classifications allows the server to skip analysis for those, which can speed up query execution.
	NotificationsDisabledClassifications notifications.NotificationDisabledClassifications
	// By default, if the server requests it, the driver will automatically transmit anonymous usage
	// statistics to the server it is connected to.
	//
	// By configuring TelemetryDisabled=True, the driver will refrain from transmitting any telemetry data.
	//
	// Each time one of the specified APIs is utilized to execute a query for the first time, the driver
	// informs the server of this action without providing additional details such as arguments or client identifiers:
	//
	//   neo4j.ExecuteQuery
	//   Session.Run
	//   Session.BeginTransaction
	//   Session.ExecuteRead
	//   Session.ExecuteWrite
	//
	// default: true
	TelemetryDisabled bool
	// ReadBufferSize defines the size of the buffer used for reading data from the network connection.
	// A larger buffer size can improve performance by reducing the number of read operations required
	// for large data transfers. Currently, the default value is 8 KiB, but may change in the future.
	// Set to 0 or below to disable buffering.
	ReadBufferSize int
}

// ServerAddressResolver is a function type that defines the resolver function used by the routing driver to
// resolve the initial address used to create the driver.
type ServerAddressResolver func(address ServerAddress) []ServerAddress

// ServerAddress represents a host and port. Host can either be an IP address or a DNS name.
// Both IPv4 and IPv6 hosts are supported.
type ServerAddress interface {
	// Hostname returns the host portion of this ServerAddress.
	Hostname() string
	// Port returns the port portion of this ServerAddress.
	Port() string
}

// NewServerAddress generates a ServerAddress with provided hostname and port information.
func NewServerAddress(hostname string, port string) ServerAddress {
	if hostname == "" {
		return nil
	}

	hostAndPort := hostname
	if port != "" {
		hostAndPort = hostAndPort + ":" + port
	}

	return &url.URL{Host: hostAndPort}
}

module github.com/grafana/pyroscope-go/godeltaprof

go 1.24.0

require github.com/klauspost/compress v1.17.8

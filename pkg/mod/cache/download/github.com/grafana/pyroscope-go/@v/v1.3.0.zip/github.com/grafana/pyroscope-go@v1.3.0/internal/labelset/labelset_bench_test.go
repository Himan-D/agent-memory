package labelset

import (
	"math/rand"
	"testing"
)

func BenchmarkKey_Parse(b *testing.B) {
	const (
		labelsSize = 10
		minLen     = 6
		maxLen     = 16
	)

	// Duplicates are okay.
	labels := make(map[string]string, labelsSize+1)
	for range labelsSize {
		labels[randString(randInt(minLen, maxLen))] = randString(randInt(minLen, maxLen))
	}

	labels["__name__"] = "benchmark.key.parse"
	keyStr := New(labels).Normalized()

	b.ReportAllocs()
	b.ResetTimer()

	for range b.N {
		if _, err := Parse(keyStr); err != nil {
			b.Fatal(err)
		}
	}
}

func randInt(minVal, maxVal int) int { return rand.Intn(maxVal-minVal) + minVal } //nolint:gosec

// TODO(kolesnikovae): This is not near perfect way of generating strings.
//  It makes sense to create a package for util functions like this.

const letterBytes = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

func randString(n int) string {
	b := make([]byte, n)
	for i := range b {
		b[i] = letterBytes[rand.Intn(len(letterBytes))] //nolint:gosec
	}

	return string(b)
}
